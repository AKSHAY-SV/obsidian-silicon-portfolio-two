import React, { useState, useEffect } from 'react';
import { 
  Cpu, Award, Zap, BookOpen, Terminal, Sliders, ShieldCheck, Layers, 
  Binary, Database, Activity, Code, Settings, ChevronRight, CheckCircle2, 
  ArrowRight, Wrench, RefreshCw, Layers3, Flame, Sparkles, ArrowUpRight, 
  GraduationCap, Briefcase, Mail, MapPin, ExternalLink, Microscope, ChevronDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
// @ts-ignore
import profilePic from '../assets/images/regenerated_image_1782761115139.png';

export default function About() {
  const potentialSources = [
    profilePic,
    'https://avatars.githubusercontent.com/aksh-ai',
    '/profile.png',
    '/profile.jpg',
    '/profile.jpeg',
    '/avatar.png',
    '/avatar.jpg',
    '/avatar.jpeg',
    'https://images.unsplash.com/photo-1607990283143-e81e7a2c93ab?q=80&w=400&auto=format&fit=crop'
  ];
  const [sourceIndex, setSourceIndex] = useState(0);
  const [selectedCatId, setSelectedCatId] = useState('comp_arch');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleImageError = () => {
    if (sourceIndex < potentialSources.length - 1) {
      setSourceIndex(sourceIndex + 1);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.12 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const }
    }
  };

  // --------------------------------------------------------------------------
  // SKILLS ARSENAL DATA (Comprehensive 12 Categories from Resume)
  // --------------------------------------------------------------------------
  const skillCategories = [
    {
      id: 'comp_arch',
      name: 'Computer Architecture',
      icon: <Microscope className="h-5 w-5 text-[#a78bfa]" />,
      skills: [
        { name: 'Pipelined Core Microarchitectures', proficiency: 98 },
        { name: 'Multi-Core Cache Coherency (MESI)', proficiency: 95 },
        { name: 'Network-on-Chip (NoC) Crossbars', proficiency: 90 }
      ]
    },
    {
      id: 'digital_design',
      name: 'Digital System Design',
      icon: <Cpu className="h-5 w-5 text-[#3b82f6]" />,
      skills: [
        { name: 'Finite State Machine (FSM)', proficiency: 98 },
        { name: 'Clock Domain Crossings (CDC)', proficiency: 88 },
        { name: 'Glitch-free Clock Gating', proficiency: 85 }
      ]
    },
    {
      id: 'rtl_design',
      name: 'RTL Coding & Verification',
      icon: <ShieldCheck className="h-5 w-5 text-[#10b981]" />,
      skills: [
        { name: 'Synthesizable Coding Styles', proficiency: 98 },
        { name: 'Register Transfer Level Timing', proficiency: 95 },
        { name: 'SystemVerilog Assertions (SVA)', proficiency: 85 }
      ]
    },
    {
      id: 'hdls',
      name: 'HDLs & Languages',
      icon: <Code className="h-5 w-5 text-[#f59e0b]" />,
      skills: [
        { name: 'SystemVerilog', proficiency: 98 },
        { name: 'Verilog', proficiency: 98 },
        { name: 'Chisel', proficiency: 75 },
        { name: 'VHDL', proficiency: 65 }
      ]
    },
    {
      id: 'eda',
      name: 'EDA Synthesis Tools',
      icon: <Settings className="h-5 w-5 text-[#e879f9]" />,
      skills: [
        { name: 'Synopsys Design Compiler', proficiency: 90 },
        { name: 'Cadence Innovus', proficiency: 90 },
        { name: 'Synopsys PrimeTime', proficiency: 85 },
        { name: 'OpenSTA', proficiency: 88 },
        { name: 'Yosys Open SY', proficiency: 92 }
      ]
    },
    {
      id: 'fpga',
      name: 'FPGA Development Tools',
      icon: <Layers3 className="h-5 w-5 text-[#06b6d4]" />,
      skills: [
        { name: 'Xilinx Vivado', proficiency: 95 },
        { name: 'Intel Quartus Prime', proficiency: 80 },
        { name: 'ModelSim / Questa', proficiency: 90 }
      ]
    },
    {
      id: 'physical',
      name: 'Physical Backend Design',
      icon: <Layers className="h-5 w-5 text-[#ec4899]" />,
      skills: [
        { name: 'Floorplanning & Power Grid', proficiency: 92 },
        { name: 'Placement Optimization', proficiency: 88 },
        { name: 'Clock Tree Synthesis (CTS)', proficiency: 85 },
        { name: 'Signal Routing & Congestion', proficiency: 90 },
        { name: 'DRC & LVS Checks', proficiency: 92 }
      ]
    },
    {
      id: 'programming',
      name: 'Programming',
      icon: <Terminal className="h-5 w-5 text-[#84cc16]" />,
      skills: [
        { name: 'C', proficiency: 95 },
        { name: 'C++', proficiency: 85 },
        { name: 'Python', proficiency: 90 },
        { name: 'Tcl Scripts', proficiency: 80 },
        { name: 'RISC-V Assembly', proficiency: 85 }
      ]
    },
    {
      id: 'analog',
      name: 'Analog IC Design',
      icon: <Flame className="h-5 w-5 text-[#f43f5e]" />,
      skills: [
        { name: 'Cadence Virtuoso', proficiency: 85 },
        { name: 'LTspice', proficiency: 90 },
        { name: 'Microwind', proficiency: 78 }
      ]
    },
    {
      id: 'embedded',
      name: 'Embedded Systems',
      icon: <Binary className="h-5 w-5 text-[#a855f7]" />,
      skills: [
        { name: 'Arduino Platform', proficiency: 95 },
        { name: 'ESP32 / Microcontrollers', proficiency: 88 },
        { name: 'FreeRTOS basics', proficiency: 75 },
        { name: 'I2C, SPI, UART Protocol Bus', proficiency: 95 }
      ]
    },
    {
      id: 'vcs',
      name: 'Version Control',
      icon: <Database className="h-5 w-5 text-[#64748b]" />,
      skills: [
        { name: 'Git version control', proficiency: 95 },
        { name: 'GitHub Actions / CI-CD', proficiency: 85 }
      ]
    },
    {
      id: 'os',
      name: 'Operating Systems',
      icon: <Sliders className="h-5 w-5 text-[#14b8a6]" />,
      skills: [
        { name: 'Linux command line', proficiency: 95 },
        { name: 'Ubuntu / Debian systems', proficiency: 95 }
      ]
    }
  ];

  // --------------------------------------------------------------------------
  // EDUCATION TIMELINE DATA (from Resume)
  // --------------------------------------------------------------------------
  const educationTimeline = [
    {
      institution: "Manipal Institute of Technology, Bengaluru",
      degree: "B.Tech in Electronics Engineering",
      specialization: "VLSI Design & Technology",
      period: "2024 — Present",
      location: "Bengaluru, Karnataka, India",
      details: "Focusing on fundamental semiconductor physics, digital integrated circuit layouts, computer architectures, and hardware description languages. Maintaining prime research focus on pipelined processor design and micro-architectural optimizations.",
      highlights: [
        "First Class academic standing across VLSI design core curriculum",
        "Developing advanced EDA lab benchmarks for synthesizable micro-cores"
      ]
    }
  ];

  // --------------------------------------------------------------------------
  // ENGINEERING METRICS DATA (from Resume)
  // --------------------------------------------------------------------------
  const engineeringMetrics = [
    { label: "Completed Projects", value: 12, suffix: "+" },
    { label: "Synthesizable RTL Modules", value: 45, suffix: "+" },
    { label: "Processor Architectures", value: 3, suffix: "" },
    { label: "Verified Peripheral IPs", value: 8, suffix: "" },
    { label: "Active EDA Tools", value: 10, suffix: "+" },
    { label: "Documentation Pages", value: 150, suffix: "+" },
    { label: "Research Articles", value: 4, suffix: "" },
    { label: "Simulation Testbenches", value: 30, suffix: "+" }
  ];

  // --------------------------------------------------------------------------
  // CERTIFICATIONS DATA (from Resume)
  // --------------------------------------------------------------------------
  const certificationCategories = [
    {
      id: "comp-arch-embedded",
      name: "Computer Architecture & Embedded Systems",
      items: [
        {
          title: "Computer Architecture Essentials on Arm",
          issuer: "Arm Education (Coursera)",
          date: "June 2026",
          category: "Computer Architecture",
          skills: ["ARM Architecture", "Processor Design", "Computer Organization", "Instruction Set Architecture"],
          verificationUrl: "https://coursera.org/verify/3NJZHUFQWWDF",
          logo: "cpu",
          authority: "Dr Khaled Benkrid, Senior Director, Education and Research (Arm Ltd)"
        },
        {
          title: "Embedded Software and Hardware Architecture",
          issuer: "University of Colorado Boulder (Coursera)",
          date: "July 2025",
          category: "Embedded Systems",
          skills: ["Embedded Systems", "Hardware Architecture", "Firmware Concepts", "Hardware-Software Co-design"],
          verificationUrl: "https://coursera.org/verify/8KD3Z90X2O44",
          logo: "binary",
          authority: "Alex Fosdick, Instructor (Electrical, Computer, and Energy Engineering)"
        }
      ]
    },
    {
      id: "programming",
      name: "Programming",
      items: [
        {
          title: "Introduction to Python",
          issuer: "Coursera Project Network",
          date: "June 2025",
          category: "Programming",
          skills: ["Python", "Scripting", "Automation"],
          verificationUrl: "https://coursera.org/verify/OK0SWDD53DAP",
          logo: "code",
          authority: "David Dalsveen, Subject Matter Expert (Freedom Learning Group)"
        }
      ]
    },
    {
      id: "artificial-intelligence",
      name: "Artificial Intelligence",
      items: [
        {
          title: "GenAI Basics – How LLMs Work",
          issuer: "Duke University (Coursera)",
          date: "June 2025",
          category: "Artificial Intelligence",
          skills: ["Large Language Models", "Prompt Engineering", "AI Fundamentals"],
          verificationUrl: "https://coursera.org/verify/T6ZM8VUTF7B7",
          logo: "sparkles",
          authority: "Derek Wales, Adjunct Professor (Data Science/Business)"
        },
        {
          title: "ChatGPT Playground for Beginners: Intro to NLP AI",
          issuer: "Coursera Project Network",
          date: "June 2025",
          category: "Artificial Intelligence",
          skills: ["ChatGPT", "NLP", "AI Tools"],
          verificationUrl: "https://coursera.org/verify/ZQK4UR1MH7ZI",
          logo: "terminal",
          authority: "Rudi Hinds, Software Engineer (Coursera Project Network)"
        },
        {
          title: "AI Tools & ChatGPT Workshop",
          issuer: "be10X",
          date: "June 2026",
          category: "Artificial Intelligence",
          skills: ["AI Productivity", "ChatGPT", "AI-assisted Coding", "AI Workflows"],
          logo: "award",
          authority: "Aditya Goenka & Aditya Kachave, Co-founders (be10X)"
        }
      ]
    }
  ];

  const getCertIcon = (logo: string) => {
    switch (logo) {
      case 'cpu':
        return <Cpu className="h-5 w-5 text-[#a78bfa] transition-all duration-300 group-hover:scale-110" />;
      case 'binary':
        return <Binary className="h-5 w-5 text-[#a78bfa] transition-all duration-300 group-hover:scale-110" />;
      case 'code':
        return <Code className="h-5 w-5 text-[#a78bfa] transition-all duration-300 group-hover:scale-110" />;
      case 'sparkles':
        return <Sparkles className="h-5 w-5 text-[#a78bfa] transition-all duration-300 group-hover:scale-110" />;
      case 'terminal':
        return <Terminal className="h-5 w-5 text-[#a78bfa] transition-all duration-300 group-hover:scale-110" />;
      case 'award':
      default:
        return <Award className="h-5 w-5 text-[#a78bfa] transition-all duration-300 group-hover:scale-110" />;
    }
  };

  // --------------------------------------------------------------------------
  // COUNT UP STAT COMPONENT
  // --------------------------------------------------------------------------
  function CountingStat({ value, suffix }: { value: number; suffix: string }) {
    const [count, setCount] = useState(0);

    useEffect(() => {
      let start = 0;
      const end = value;
      if (end === 0) return;
      const totalDuration = 1000; // ms
      const stepTime = Math.max(Math.floor(totalDuration / end), 15);
      
      const timer = setInterval(() => {
        start += 1;
        setCount(start);
        if (start >= end) {
          clearInterval(timer);
        }
      }, stepTime);

      return () => clearInterval(timer);
    }, [value]);

    return (
      <span className="font-mono text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
        {count}{suffix}
      </span>
    );
  }

  return (
    <div className="py-12 text-slate-100 overflow-hidden" id="about-page">
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-16"
      >
        
        {/* Editorial Subheader */}
        <div className="flex flex-col-reverse lg:flex-row items-center justify-between gap-12 pb-10 border-b border-[rgba(255,255,255,0.06)]">
          <motion.div
            variants={itemVariants}
            className="text-center lg:text-left flex-1"
          >
            <span className="font-mono text-xs font-bold uppercase tracking-[0.25em] text-[#a78bfa] flex items-center justify-center lg:justify-start gap-1.5">
              <span className="h-2 w-2 rounded-full bg-[#a78bfa] animate-pulse" />
              // BIOGRAPHY & DESIGN PRINCIPLES
            </span>
            <h1 className="mt-4 font-mono text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white uppercase leading-[1.05]">
              Akshay Srikrishnan:<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#a78bfa] via-[#c084fc] to-[#e879f9] drop-shadow-md">Focusing on Silicon Foundations.</span>
            </h1>
            <p className="mt-5 text-base sm:text-lg text-slate-300 font-sans max-w-3xl leading-relaxed font-light">
              I am an undergraduate electronics student exploring the intersection of computer architecture, synthesizable RTL modules, and physical design flows. My absolute focus lies in crafting robust, compiler-ready, and functionally sound digital integrated circuits.
            </p>
          </motion.div>
 
          {/* Profile Picture with Elegant Circular Border */}
          <motion.div
            variants={itemVariants}
            className="shrink-0 relative group"
          >
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-[#a78bfa] to-[#d8b4fe] opacity-25 blur-3xl group-hover:opacity-50 group-hover:scale-105 transition-all duration-700" />
            
            <div className="relative h-48 w-48 rounded-full p-[4px] bg-gradient-to-tr from-[#a78bfa] via-[rgba(167,139,250,0.3)] to-[#c084fc] shadow-[0_0_40px_rgba(167,139,250,0.15)] transition-all duration-500 group-hover:scale-105 group-hover:shadow-[0_0_50px_rgba(167,139,250,0.35)]">
              <div className="h-full w-full rounded-full bg-[#0a0a0c] overflow-hidden border-2 border-black/90 flex items-center justify-center">
                <img
                  id="about-profile-image"
                  src={potentialSources[sourceIndex]}
                  alt="Akshay Srikrishnan - VLSI Design & Technology Professional Headshot"
                  onError={handleImageError}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover object-center transition-all duration-700 ease-out group-hover:scale-105"
                />
              </div>
            </div>
            
            <div className="absolute bottom-2 right-3 bg-[#0c0c0c] border-2 border-[#a78bfa] rounded-full h-6 w-6 flex items-center justify-center shadow-lg shadow-black z-10">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>
          </motion.div>
        </div>

        {/* Narrative & Philosophy Grid */}
        <motion.div
          variants={itemVariants}
          className="grid grid-cols-1 lg:grid-cols-12 gap-8"
        >
          {/* Main Story column */}
          <div className="lg:col-span-8 space-y-6">
            <div className="flex items-center gap-2 border-b border-[rgba(255,255,255,0.08)] pb-3">
              <BookOpen className="h-5 w-5 text-[#a78bfa]" />
              <h2 className="font-mono text-lg font-bold uppercase tracking-wider text-white">
                My Journey into Hardware
              </h2>
            </div>
            <div className="space-y-4 font-sans text-sm text-slate-300 leading-relaxed">
              <p>
                My interest in VLSI started when I realized that every piece of software eventually compiles down to physical states on silicon. I began by learning Verilog, which quickly evolved into an obsession with how digital circuits are designed, simulated, and mapped onto micro-chip physical boundaries. Writing synthesizable logic and observing wave cycles match target operations under verification tools was incredibly rewarding.
              </p>
              <p>
                As I continued to learn, I shifted from writing basic state machines to designing complete, highly complex digital systems. I designed an 8-bit accumulator-based micro-core before architecting a fully synthesizable 5-stage pipelined RISC-V CPU. In this project, I resolved Read-After-Write (RAW) data hazards by developing a comprehensive bypass forwarding network and implemented an iterative Radix-4 Booth Multiplier. Moving up the stack, I integrated this pipeline with multi-core coherent L2 MESI caches, an AXI4 non-blocking matrix, and APB register interfaces.
              </p>
              <p>
                To bridge logic with physics, I explored physical implementation flows. I synthesized, floorplanned, routed, and timing-analyzed my RISC-V cores using modern electronic design automation (EDA) environments such as Cadence Innovus, Synopsys Design Compiler, and the OpenLane toolchain. Closing timing violations by optimizing placement density and CTS skew grids helped me appreciate how critical physical constraints are to initial RTL partitioning.
              </p>
              <p>
                Today, I continue to deepen my expertise in computer architecture, formal verification, FPGA development, and ASIC physical design flows. My objective is to become a physical silicon design engineer capable of taking highly complex architecture specs from initial concept to verified, tape-out-ready GDSII layouts.
              </p>
            </div>
          </div>

          {/* Core Design Tenets column */}
          <div className="lg:col-span-4 bg-[#0a0a0d] border border-[rgba(255,255,255,0.06)] rounded-xl p-8 shadow-md hover:border-[#a78bfa]/20 transition-all duration-300 h-fit space-y-8">
            <h3 className="font-mono text-base sm:text-lg font-bold uppercase text-white tracking-wider border-b border-[rgba(255,255,255,0.08)] pb-3 flex items-center gap-2">
              <Sliders className="h-5 w-5 text-[#a78bfa]" />
              Design Tenets
            </h3>
            <ul className="space-y-6 font-sans text-sm text-slate-300">
              <li className="flex gap-4">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#a78bfa]/10 border border-[#a78bfa]/20 text-[#a78bfa]">
                  <Zap className="h-5 w-5" />
                </div>
                <div>
                  <strong className="text-white block font-mono text-[13px] sm:text-sm uppercase tracking-wider mb-1.5">Synthesizable First</strong>
                  Every hardware line is authored with strict awareness of hardware compilers, eliminating latches and clock glitches.
                </div>
              </li>
              <li className="flex gap-4">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#10b981]/10 border border-[#10b981]/20 text-[#10b981]">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <div>
                  <strong className="text-white block font-mono text-[13px] sm:text-sm uppercase tracking-wider mb-1.5">Formal Sufficiency</strong>
                  Verification is treated with equal weight to implementation. SVA assertions are bound to verify boundary transactions mathematically.
                </div>
              </li>
              <li className="flex gap-4">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#f59e0b]/10 border border-[#f59e0b]/20 text-[#f59e0b]">
                  <Layers className="h-5 w-5" />
                </div>
                <div>
                  <strong className="text-white block font-mono text-[13px] sm:text-sm uppercase tracking-wider mb-1.5">Physical Co-Design</strong>
                  RTL structure must reflect die floorplans. Clock networks and metal spacing density guide functional group clustering.
                </div>
              </li>
            </ul>
          </div>
        </motion.div>

        {/* Core Engineering Metrics Panel (Moved from Resume) */}
        <motion.div variants={itemVariants} className="space-y-6">
          <div>
            <span className="font-mono text-xs font-bold uppercase tracking-wider text-[#a78bfa] block">// PERFORMANCE SCORES</span>
            <h2 className="mt-2 font-mono text-2xl font-extrabold tracking-tight text-white uppercase">
              Engineering Core Metrics
            </h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {engineeringMetrics.map((m, idx) => (
              <motion.div
                key={idx}
                whileHover={{ y: -3, borderColor: 'rgba(167, 139, 250, 0.3)' }}
                className="rounded-lg border border-[rgba(255,255,255,0.06)] bg-[#0d0d0d] p-5 text-center shadow-md relative"
              >
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#a78bfa]/25 to-transparent" />
                <CountingStat value={m.value} suffix={m.suffix} />
                <p className="mt-2 font-mono text-[10px] text-slate-400 uppercase tracking-wider leading-tight">
                  {m.label}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Technical Skills - Custom Dropdown Selector */}
        <motion.div variants={itemVariants} className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <span className="font-mono text-xs font-semibold text-[#a78bfa] uppercase tracking-wider">// TECHNICAL ARSENAL</span>
              <h2 className="mt-2 font-mono text-2xl font-extrabold tracking-tight text-white uppercase">
                Core Technical Disciplines
              </h2>
            </div>

            {/* Custom Interactive Dropdown Selector */}
            <div className="relative w-full md:w-80 z-20">
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="flex w-full items-center justify-between gap-3 rounded-xl border border-[rgba(255,255,255,0.08)] bg-[#0d0d0d] px-4 py-3 text-left text-xs font-mono text-white shadow-lg focus-visible:ring-2 focus-visible:ring-[#a78bfa] focus-visible:outline-none transition-all duration-200 hover:border-[#a78bfa]/40 hover:bg-[#121215]"
              >
                <div className="flex items-center gap-2.5">
                  <div className="text-[#a78bfa] shrink-0">
                    {skillCategories.find(c => c.id === selectedCatId)?.icon}
                  </div>
                  <span className="font-bold tracking-wide uppercase truncate max-w-[180px]">
                    {skillCategories.find(c => c.id === selectedCatId)?.name}
                  </span>
                </div>
                <ChevronDown className={`h-4 w-4 text-[#94a3b8] shrink-0 transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {isDropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-30" onClick={() => setIsDropdownOpen(false)} />
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 left-0 mt-2 max-h-[280px] overflow-y-auto rounded-xl border border-[rgba(255,255,255,0.1)] bg-[#0d0d0df9] p-1.5 backdrop-blur-xl shadow-2xl z-40 divide-y divide-[rgba(255,255,255,0.04)] scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent"
                    >
                      {skillCategories.map((cat) => (
                        <button
                          key={cat.id}
                          onClick={() => {
                            setSelectedCatId(cat.id);
                            setIsDropdownOpen(false);
                          }}
                          className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left transition-all ${
                            selectedCatId === cat.id
                              ? 'bg-[#a78bfa]/10 text-[#a78bfa] font-bold'
                              : 'text-slate-300 hover:bg-white/5 hover:text-white'
                          }`}
                        >
                          <div className="shrink-0 text-slate-400">
                            {cat.icon}
                          </div>
                          <span className="font-mono text-[11px] uppercase tracking-wider">{cat.name}</span>
                        </button>
                      ))}
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Selected Category Details Card */}
          <div className="flex justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedCatId}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
                className="w-full max-w-4xl rounded-2xl border border-[rgba(255,255,255,0.08)] bg-[#0d0d0d]/40 p-6 sm:p-8 space-y-6 shadow-xl relative overflow-hidden group hover:border-[#a78bfa]/20 transition-all duration-300"
              >
                {/* Visual highlights */}
                <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#a78bfa]/30 to-transparent" />
                <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-[#a78bfa]/5 rounded-full blur-3xl pointer-events-none" />

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[rgba(255,255,255,0.06)] pb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-slate-900 border border-[rgba(255,255,255,0.06)] text-[#a78bfa] shadow-inner">
                      {skillCategories.find(c => c.id === selectedCatId)?.icon}
                    </div>
                    <div>
                      <span className="font-mono text-[9px] text-slate-500 uppercase tracking-widest block mb-0.5">// ACTIVE STREAM</span>
                      <h3 className="font-mono text-base font-bold text-white uppercase tracking-wider">
                        {skillCategories.find(c => c.id === selectedCatId)?.name}
                      </h3>
                    </div>
                  </div>
                  <div className="font-mono text-[10px] text-slate-400 bg-slate-900/50 px-3 py-1.5 rounded-lg border border-[rgba(255,255,255,0.04)] h-fit w-fit">
                    {skillCategories.find(c => c.id === selectedCatId)?.skills.length} core metrics active
                  </div>
                </div>

                <div className="space-y-5 pt-2">
                  {skillCategories.find(c => c.id === selectedCatId)?.skills.map((skill, sIdx) => (
                    <div key={sIdx} className="space-y-2">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-slate-200 font-bold uppercase tracking-wide flex items-center gap-2">
                          <span className="h-1.5 w-1.5 rounded-full bg-[#a78bfa] shadow-[0_0_6px_rgba(167,139,250,0.8)]" />
                          {skill.name}
                        </span>
                        <span className="text-[#a78bfa] font-bold">{skill.proficiency}% verified proficiency</span>
                      </div>
                      <div className="h-2 w-full bg-neutral-950 rounded-full overflow-hidden relative border border-white/5">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${skill.proficiency}%` }}
                          transition={{ duration: 0.8, ease: 'easeOut' }}
                          className="h-full bg-gradient-to-r from-[#a78bfa] via-[#c084fc] to-[#e879f9] rounded-full relative"
                        >
                          <div className="absolute top-0 right-0 h-full w-2 bg-white/20 blur-[1px]" />
                        </motion.div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Academic Timeline */}
        <motion.div variants={itemVariants} className="space-y-6">
          <div>
            <span className="font-mono text-xs font-semibold text-[#a78bfa] uppercase tracking-wider">// SCHOLASTIC PIPELINE</span>
            <h2 className="mt-2 font-mono text-2xl font-extrabold tracking-tight text-white uppercase">
              Academic Background
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left side: Timeline cards */}
            <div className="lg:col-span-12 relative border-l border-[#a78bfa]/25 pl-6 ml-3 space-y-8">
              {educationTimeline.map((edu, idx) => (
                <div key={idx} className="relative">
                  {/* Node pin */}
                  <div className="absolute -left-[34px] top-1.5 h-4 w-4 rounded-full bg-[#080808] border-2 border-[#a78bfa] flex items-center justify-center shadow-[0_0_8px_rgba(167,139,250,0.4)]">
                    <div className="h-1.5 w-1.5 rounded-full bg-[#a78bfa]" />
                  </div>

                  <motion.div
                    whileHover={{ borderColor: 'rgba(167, 139, 250, 0.3)' }}
                    className="rounded-lg border border-[rgba(255,255,255,0.06)] bg-[#0d0d0d] p-6"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-3">
                      <span className="font-mono text-xs font-bold text-[#a78bfa]">{edu.period}</span>
                      <span className="font-mono text-[11px] text-slate-500 uppercase">{edu.location}</span>
                    </div>

                    <h4 className="font-sans text-lg font-black text-white uppercase tracking-tight">
                      {edu.institution}
                    </h4>
                    <p className="font-mono text-xs text-slate-300 font-semibold mt-0.5 uppercase tracking-wide">
                      {edu.degree} — {edu.specialization}
                    </p>
                    
                    <p className="mt-4 font-sans text-xs text-slate-400 leading-relaxed">
                      {edu.details}
                    </p>

                    <div className="mt-4 pt-4 border-t border-[rgba(255,255,255,0.06)] space-y-2">
                      <span className="font-mono text-[10px] text-slate-500 uppercase tracking-widest block font-bold">// KEY FOCUS AREAS</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {edu.highlights.map((h, hidx) => (
                          <div key={hidx} className="flex items-start gap-2 text-xs text-slate-300">
                            <CheckCircle2 className="h-4 w-4 text-[#a78bfa] shrink-0 mt-0.5" />
                            <span>{h}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Technical Certifications */}
        <motion.div variants={itemVariants} className="space-y-6">
          <div>
            <span className="font-mono text-xs font-bold uppercase tracking-wider text-[#a78bfa] block">// ACCREDITED NETLIST</span>
            <h2 className="mt-2 font-mono text-2xl font-extrabold tracking-tight text-white uppercase">
              Technical Certifications
            </h2>
          </div>

          <div className="space-y-8">
            {certificationCategories.map((cat) => (
              <div key={cat.id} className="space-y-4">
                <div className="flex items-center gap-2 border-b border-[rgba(255,255,255,0.06)] pb-2">
                  <span className="font-mono text-xs font-bold text-[#a78bfa] uppercase tracking-wide">
                    {cat.name}
                  </span>
                  <span className="font-mono text-[10px] text-slate-500 font-bold">({cat.items.length})</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {cat.items.map((cert, certIdx) => (
                    <motion.div
                      key={certIdx}
                      whileHover={{ y: -4 }}
                      className="group relative rounded-lg border border-[rgba(255,255,255,0.06)] bg-[#0c0c0c] p-5 flex flex-col justify-between hover:border-[#a78bfa]/40 hover:bg-[#121212]/50 transition-all duration-300 shadow-md hover:shadow-lg hover:shadow-[#a78bfa]/5"
                    >
                      <div className="space-y-4">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-[9px] text-[#a78bfa] uppercase font-bold tracking-wider bg-[#a78bfa]/5 px-2 py-0.5 rounded border border-[#a78bfa]/10">
                            {cert.category}
                          </span>
                          <span className="font-mono text-[10px] text-slate-500">{cert.date}</span>
                        </div>

                        <div className="flex gap-3 items-start">
                          <div className="h-9 w-9 rounded-md bg-[#161616] border border-[rgba(255,255,255,0.08)] flex items-center justify-center shrink-0 group-hover:border-[#a78bfa]/30 transition-all duration-300">
                            {getCertIcon(cert.logo)}
                          </div>
                          <div>
                            <h4 className="font-sans font-extrabold text-white text-xs sm:text-sm tracking-wide uppercase leading-snug group-hover:text-[#a78bfa] transition-colors duration-300">
                              {cert.title}
                            </h4>
                            <p className="mt-1 font-sans text-xs text-slate-400 font-medium leading-none">
                              {cert.issuer}
                            </p>
                          </div>
                        </div>

                        <div className="pt-2">
                          <span className="font-mono text-[8px] text-slate-500 uppercase tracking-widest block font-bold mb-1.5">// SKILLS ACQUIRED</span>
                          <div className="flex flex-wrap gap-1.5">
                            {cert.skills.map((skill) => (
                              <span
                                key={skill}
                                className="rounded bg-[#121212] border border-[rgba(255,255,255,0.06)] px-2 py-0.5 font-mono text-[9px] text-slate-300 group-hover:border-[#a78bfa]/20 transition-all duration-300"
                              >
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {cert.verificationUrl && (
                        <div className="mt-6 pt-3 border-t border-[rgba(255,255,255,0.04)] flex justify-end">
                          <a
                            href={cert.verificationUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 font-mono text-[10px] text-[#a78bfa] font-bold uppercase hover:text-white transition-colors duration-200"
                          >
                            View Credential
                            <ArrowUpRight className="h-3.5 w-3.5" />
                          </a>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

      </motion.div>
    </div>
  );
}
