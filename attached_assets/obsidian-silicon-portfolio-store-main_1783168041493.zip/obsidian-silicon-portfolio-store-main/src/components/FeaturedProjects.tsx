import React from 'react';
import { motion } from 'motion/react';
import { PROJECTS } from '../data';
import { Project } from '../types';
import { 
  Cpu, ArrowUpRight, Layers, Settings2, ShieldCheck, 
  Terminal, Activity, Zap, CheckCircle 
} from 'lucide-react';

interface FeaturedProjectsProps {
  setActiveTab: (tab: any) => void;
}

export default function FeaturedProjects({ setActiveTab }: FeaturedProjectsProps) {
  // Extract the three most important engineering projects
  const featuredIds = ['rv32im-soc-processor', 'rv32im-core', 'l2-cache-controller'];
  const featuredProjects = PROJECTS.filter(proj => featuredIds.includes(proj.id));

  // If some are missing for any reason, grab the first three from PROJECTS
  const projectsToDisplay = featuredProjects.length === 3 
    ? featuredProjects 
    : PROJECTS.slice(0, 3);

  // Status map to display clean human labels
  const getStatusDisplay = (id: string) => {
    switch(id) {
      case 'rv32im-soc-processor':
        return { label: 'TAPEOUT COMPLETE', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
      case 'rv32im-core':
        return { label: 'RTL VERIFIED', color: 'text-[#a78bfa] bg-[#a78bfa]/10 border-[#a78bfa]/30' };
      case 'l2-cache-controller':
        return { label: 'FORMAL SIGN-OFF', color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30' };
      default:
        return { label: 'VERIFIED', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
    }
  };

  // Get project core icon
  const getProjectIcon = (id: string) => {
    switch(id) {
      case 'rv32im-soc-processor':
        return Cpu;
      case 'rv32im-core':
        return Terminal;
      case 'l2-cache-controller':
        return Layers;
      default:
        return Settings2;
    }
  };

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const }
    },
  };

  const handleViewDetails = (projectId: string) => {
    let slug = '';
    if (projectId === 'rv32im-core') slug = 'rv32im-processor';
    else if (projectId === 'l2-cache-controller') slug = 'cache-memory';
    else if (projectId === 'rv32im-soc-processor') slug = 'rv32im-processor';

    if (slug) {
      setActiveTab(`/projects/${slug}`);
    } else {
      setActiveTab('projects');
    }
  };

  return (
    <section className="py-20 border-b border-[rgba(255,255,255,0.06)] bg-[#09090d] relative overflow-hidden" id="featured-projects">
      {/* Silicon Wafer decorative background line */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(167,139,250,0.008)_1px,transparent_1px),linear-gradient(to_bottom,rgba(167,139,250,0.008)_1px,transparent_1px)] bg-[size:4rem_4rem] z-0 pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[45rem] h-[25rem] bg-[#a78bfa]/1 rounded-full blur-[140px] pointer-events-none z-0" />

      <div className="mx-auto max-w-7xl xl:max-w-screen-2xl px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="mb-14 text-center max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full px-3 py-1 bg-slate-950/80 border border-slate-800 font-mono text-[9px] lg:text-[10px] tracking-[0.2em] text-[#a78bfa] uppercase mb-4"
          >
            <Activity className="h-3 w-3 animate-pulse" />
            // SILICON_REPORTS_LOADED
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="font-display text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white uppercase leading-[1.1]"
          >
            Featured Engineering Projects
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-3 font-sans text-sm lg:text-base text-[#94a3b8] leading-relaxed lg:leading-loose max-w-2xl lg:max-w-3xl mx-auto"
          >
            Explore core semiconductor designs, from synthesizable multicore coherent memory models to fully taped-out RISC-V micro-architectures.
          </motion.p>
        </div>

        {/* Responsive Grid Layout */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10"
        >
          {projectsToDisplay.map((proj) => {
            const IconComponent = getProjectIcon(proj.id);
            const statusInfo = getStatusDisplay(proj.id);

            return (
              <motion.div
                key={proj.id}
                variants={cardVariants}
                whileHover={{ y: -6, borderColor: 'rgba(167, 139, 250, 0.28)' }}
                className="group rounded-xl border border-slate-800/60 bg-[#0d0d14]/75 backdrop-blur-md p-6 lg:p-8 flex flex-col justify-between transition-all duration-300 shadow-xl relative overflow-hidden"
              >
                {/* Visual Accent Line at Top */}
                <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#a78bfa]/20 to-transparent group-hover:via-[#a78bfa]/60 transition-all duration-300" />

                <div>
                  {/* Status Indicator & Icon */}
                  <div className="flex items-center justify-between gap-4 mb-5 lg:mb-6">
                    <div className="flex h-10 w-10 lg:h-12 lg:w-12 items-center justify-center rounded-lg bg-[#a78bfa]/5 border border-slate-800/80 text-[#a78bfa] group-hover:bg-[#a78bfa]/10 transition-colors">
                      <IconComponent className="h-5 w-5 lg:h-6 lg:w-6" />
                    </div>
                    
                    <span className={`px-2.5 py-0.5 lg:px-3 lg:py-1 rounded font-mono text-[9px] lg:text-[10px] font-bold border tracking-wider uppercase ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                  </div>

                  {/* Title & Tagline */}
                  <h3 className="font-display text-base lg:text-lg xl:text-xl font-extrabold text-white uppercase tracking-wide group-hover:text-[#c084fc] transition-colors duration-200">
                    {proj.name}
                  </h3>
                  
                  <p className="mt-1.5 font-mono text-[10px] lg:text-[11.5px] text-[#a78bfa]/80 uppercase leading-snug">
                    {proj.tagline}
                  </p>

                  <p className="mt-4 font-sans text-xs lg:text-sm text-[#94a3b8] leading-relaxed lg:leading-loose line-clamp-3">
                    {proj.description}
                  </p>
                </div>

                <div>
                  {/* Technology Badges */}
                  <div className="mt-6 flex flex-wrap gap-1.5 lg:gap-2">
                    {proj.techStack.slice(0, 3).map((tech, i) => (
                      <span 
                        key={i} 
                        className="rounded bg-[#a78bfa]/5 border border-[#a78bfa]/10 px-2.5 py-0.5 lg:px-3 lg:py-1 font-mono text-[9px] lg:text-[10px] text-[#a78bfa]/90"
                      >
                        {tech}
                      </span>
                    ))}
                    {proj.techStack.length > 3 && (
                      <span className="rounded bg-slate-900 border border-slate-800 px-2 py-0.5 lg:px-2.5 lg:py-1 font-mono text-[9px] lg:text-[10px] text-slate-500">
                        +{proj.techStack.length - 3} MORE
                      </span>
                    )}
                  </div>

                  {/* Metrics Box (Quick Hardware Profile) */}
                  <div className="mt-5 p-3 lg:p-4 rounded bg-slate-950/60 border border-slate-900 flex justify-between items-center text-[9px] lg:text-[10px] font-mono text-slate-400">
                    <span className="flex items-center gap-1">
                      <Zap className="h-3 w-3 lg:h-3.5 lg:w-3.5 text-amber-500" />
                      {proj.metrics.frequency || 'N/A'}
                    </span>
                    <span className="text-slate-600">|</span>
                    <span>
                      {proj.metrics.power || 'N/A'}
                    </span>
                    <span className="text-slate-600">|</span>
                    <span>
                      {proj.metrics.lutCount || proj.metrics.area || 'N/A'}
                    </span>
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={() => handleViewDetails(proj.id)}
                    className="mt-6 w-full py-2.5 lg:py-3.5 rounded border border-slate-800 hover:border-[#a78bfa]/45 bg-slate-950/40 hover:bg-[#a78bfa]/5 font-mono text-[10px] lg:text-xs font-bold uppercase tracking-wider text-slate-200 hover:text-white transition-all duration-200 flex items-center justify-center gap-1.5 group/btn cursor-pointer"
                  >
                    // INITIALIZE_WORKSPACE
                    <ArrowUpRight className="h-3 w-3 lg:h-3.5 lg:w-3.5 text-slate-400 group-hover/btn:text-[#a78bfa] group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform duration-200" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
