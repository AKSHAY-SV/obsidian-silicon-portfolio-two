import React from 'react';
import { motion } from 'motion/react';
import { Cpu } from 'lucide-react';
import { DETAILED_PROJECTS } from '../data/detailedProjects';

interface ProjectsLibraryProps {
  setActiveTab?: (tab: string) => void;
}

export default function ProjectsLibrary({ setActiveTab }: ProjectsLibraryProps) {
  return (
    <section className="py-12 md:py-16 bg-[#0c0c0c] text-white" id="projects-showcase-section">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10 text-center md:text-left">
          <span className="font-mono text-xs font-bold uppercase tracking-widest text-[#a78bfa] block mb-2">
            // SILICON IP BLOCKS
          </span>
          <h2 className="font-display text-3xl font-black tracking-tight text-white sm:text-4xl lg:text-5xl uppercase leading-[1.1]">
            Featured Hardware Projects
          </h2>
          <p className="mt-3 font-sans text-xs sm:text-sm text-slate-400 max-w-2xl">
            A comprehensive list of synthesizable processor cores, cache memory maps, and high-speed analog/digital transceivers. Click any module block to pull up complete layout parameters, formal RTL timing assertions, and GTKWave trace logs.
          </p>
        </div>

        {/* FEATURED PROJECTS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {DETAILED_PROJECTS.map((p, idx) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05 }}
              whileHover={{ y: -6, borderColor: 'rgba(167, 139, 250, 0.4)' }}
              className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0c0c0c] overflow-hidden flex flex-col justify-between group h-full shadow-lg transition-all duration-300"
            >
              <div>
                {/* Project Image */}
                <div className="h-44 w-full relative overflow-hidden bg-neutral-900 border-b border-[rgba(255,255,255,0.06)]">
                  <img 
                    src={p.image} 
                    alt={p.name} 
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500"
                  />
                  <div className="absolute top-3 left-3 rounded bg-black/75 px-2 py-0.5 border border-[rgba(255,255,255,0.1)] font-mono text-[9px] font-bold text-[#a78bfa] uppercase">
                    {p.category}
                  </div>
                </div>

                {/* Project Content */}
                <div className="p-5 space-y-3">
                  <h4 className="font-sans text-base font-extrabold text-white uppercase tracking-wide group-hover:text-[#a78bfa] transition-colors">
                    {p.name}
                  </h4>
                  <span className="font-mono text-[10px] text-[#a78bfa]/80 block font-bold -mt-1.5 uppercase tracking-wide">
                    {p.tagline}
                  </span>
                  <p className="font-sans text-xs text-slate-400 leading-relaxed">
                    {p.description}
                  </p>

                  {/* Tech Badges */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {p.techStack.map((tech) => (
                      <span key={tech} className="rounded bg-[#121212] border border-[rgba(255,255,255,0.06)] px-1.5 py-0.5 font-mono text-[9px] text-slate-400">
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Specifications / Highlights */}
                  <div className="pt-3 border-t border-[rgba(255,255,255,0.06)] space-y-1.5">
                    <span className="font-mono text-[9px] text-slate-500 uppercase tracking-widest block font-bold">// KEY SPECIFICATIONS</span>
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-400">
                      {p.metrics.slice(0, 2).map((m, mIdx) => (
                        <div key={mIdx} className="bg-[#121212]/50 p-1.5 rounded border border-[rgba(255,255,255,0.03)]">
                          <span className="text-slate-500 block text-[8px] uppercase">{m.label}</span>
                          <span className="text-white font-bold block">{m.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0">
                <button
                  onClick={() => {
                    if (setActiveTab) {
                      setActiveTab(`/projects/${p.slug}`);
                    } else {
                      window.history.pushState({ tab: `/projects/${p.slug}` }, '', `/projects/${p.slug}`);
                      window.dispatchEvent(new Event('popstate'));
                    }
                  }}
                  className="w-full text-center rounded bg-[#121212] border border-[rgba(255,255,255,0.1)] hover:bg-[#1a1a1a] hover:border-[#a78bfa]/40 text-slate-300 hover:text-white py-2 font-mono text-xs uppercase font-bold tracking-wider transition-all cursor-pointer"
                >
                  View Complete Project
                </button>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
