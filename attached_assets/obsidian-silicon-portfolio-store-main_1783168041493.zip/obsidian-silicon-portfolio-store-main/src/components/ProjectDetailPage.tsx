import React from 'react';
import { motion } from 'motion/react';
import { ProjectDetail } from '../data/detailedProjects';
import { 
  ArrowLeft, Cpu, Layers, ShieldCheck, Download, Code, Waves, 
  Microscope, FileText, Settings2, Sliders, Activity, Image, BookOpen, Clock, 
  PlayCircle, Eye, GitBranch, Binary
} from 'lucide-react';

interface ProjectDetailPageProps {
  project: ProjectDetail;
  onBack: () => void;
}

export default function ProjectDetailPage({ project, onBack }: ProjectDetailPageProps) {
  // Staggered animation configurations
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.08 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const }
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#0a0a0d] text-white py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden" id="project-detail-container">
      {/* Silicon design decorative grid lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(167,139,250,0.005)_1px,transparent_1px),linear-gradient(to_bottom,rgba(167,139,250,0.005)_1px,transparent_1px)] bg-[size:4rem_4rem] z-0 pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-[35rem] h-[35rem] bg-[#a78bfa]/2 rounded-full blur-[140px] pointer-events-none z-0" />
      <div className="absolute bottom-1/4 left-1/4 w-[35rem] h-[35rem] bg-[#e879f9]/1 rounded-full blur-[140px] pointer-events-none z-0" />

      <div className="mx-auto max-w-5xl relative z-10 space-y-12">
        
        {/* BACK TO PROJECTS BUTTON */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }}>
          <button
            onClick={onBack}
            className="group flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-800/80 bg-slate-950/40 hover:bg-[#a78bfa]/5 hover:border-[#a78bfa]/30 font-mono text-xs uppercase tracking-widest text-[#a78bfa] transition-all duration-200 cursor-pointer"
            id="btn-back-to-projects"
          >
            <ArrowLeft className="h-4 w-4 transition-transform duration-200 group-hover:-translate-x-1" />
            // BACK_TO_PROJECTS
          </button>
        </motion.div>

        {/* 1. PROJECT HERO */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-2xl border border-[rgba(255,255,255,0.06)] bg-gradient-to-br from-[#0c0c14]/90 to-[#07070a]/95 backdrop-blur-md p-6 sm:p-10 shadow-2xl relative overflow-hidden"
          id="project-hero"
        >
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#a78bfa]/40 to-transparent" />
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            <div className="md:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 rounded px-2.5 py-0.5 bg-[#a78bfa]/10 border border-[#a78bfa]/30 font-mono text-[10px] font-bold text-[#a78bfa] uppercase tracking-wider">
                <Cpu className="h-3 w-3 animate-pulse" />
                {project.category}
              </div>
              
              <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white uppercase leading-[1.05]" id="project-title">
                {project.name}
              </h1>
              
              <p className="font-mono text-xs sm:text-sm text-[#a78bfa]/80 uppercase font-semibold tracking-wider">
                {project.tagline}
              </p>
              
              <p className="font-sans text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
                {project.description}
              </p>

              {/* Technology Badges */}
              <div className="flex flex-wrap gap-2 pt-2">
                {project.techStack.map((tech) => (
                  <span 
                    key={tech} 
                    className="rounded bg-[#12121c] border border-[rgba(255,255,255,0.06)] px-3 py-1 font-mono text-[10px] text-slate-300 shadow-sm"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Spec Quick Box */}
            <div className="md:col-span-4 rounded-xl bg-slate-950/60 border border-slate-900/80 p-5 space-y-4 font-mono text-xs shadow-inner">
              <span className="block text-[10px] text-slate-500 uppercase font-bold tracking-widest border-b border-[rgba(255,255,255,0.06)] pb-2">// HARDWARE SIGNALS</span>
              <div className="space-y-3">
                {project.metrics.map((metric, i) => (
                  <div key={i} className="flex justify-between items-center pb-2 border-b border-[rgba(255,255,255,0.03)] last:border-0 last:pb-0">
                    <span className="text-slate-400">{metric.label}:</span>
                    <span className="text-white font-bold text-right">{metric.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* DETAILS SECTION ARCHITECTURE (GRID CONTENT) */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-12 gap-8"
        >
          {/* Left Column (Main documentation flow) */}
          <div className="md:col-span-8 space-y-10">
            
            {/* 2. PROJECT OVERVIEW */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Sliders className="h-4 w-4" /> [02] Project Overview
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed space-y-3">
                <p>{project.overview}</p>
                <p className="text-xs text-slate-400">
                  This architecture was specified to deliver optimized throughput under targeted silicon workloads, emphasizing synchronous hardware verification methodologies and race-free physical boundary conditions.
                </p>
              </div>
            </motion.section>

            {/* 3. PROBLEM STATEMENT */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Activity className="h-4 w-4 text-amber-400" /> [03] Problem Statement
              </h3>
              <div className="rounded-xl border border-amber-500/10 bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed">
                <p className="font-mono text-xs text-amber-400/90 font-bold uppercase tracking-wide mb-2">// DETECTED HARDWARE BOTTLENECK</p>
                <p>
                  {project.challenges || "Transistor mismatches, high routing congestion in top metal layers, and propagation delays on multi-cycle mathematical pathways constrained maximum operating frequencies and triggered meta-stability flags."}
                </p>
              </div>
            </motion.section>

            {/* 4. DESIGN OBJECTIVES */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <ShieldCheck className="h-4 w-4" /> [04] Design Objectives
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 space-y-4">
                <p className="font-sans text-sm text-slate-300 leading-relaxed">
                  The primary physical and architectural targets established for this micro-component include:
                </p>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs text-slate-400">
                  <li className="flex items-center gap-2.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#a78bfa]" /> Zero floating nodes or dynamic latches
                  </li>
                  <li className="flex items-center gap-2.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#a78bfa]" /> Clock skew bound under 35ps
                  </li>
                  <li className="flex items-center gap-2.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#a78bfa]" /> Synchronous active-low system reset
                  </li>
                  <li className="flex items-center gap-2.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#a78bfa]" /> Standard cell library compatibility
                  </li>
                </ul>
              </div>
            </motion.section>

            {/* 5. ARCHITECTURE */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Layers className="h-4 w-4" /> [05] Architecture Specifications
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed space-y-4">
                <p>{project.architecture}</p>
                <p>
                  By decoupling sequential memory transactions from combinational execution lines, the architecture preserves single-cycle operation across register banks. The state flow diagram centers around a classical modular finite state machine (FSM).
                </p>
              </div>
            </motion.section>

            {/* 6. RTL SOURCE CODE */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Code className="h-4 w-4" /> [06] RTL Source Code
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed">
                <p>The complete RTL implementation and source files will be added here in a future update.</p>
              </div>
            </motion.section>

            {/* 7. BLOCK DIAGRAM */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <GitBranch className="h-4 w-4" /> [07] Structural Block Diagram
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0d0d12] p-8 text-center space-y-4 min-h-[16rem] flex flex-col justify-center items-center">
                <Binary className="h-10 w-10 text-[#a78bfa] opacity-60 animate-bounce" />
                <div>
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-white">RTL Architecture Diagram Placeholder</h4>
                  <p className="font-sans text-xs text-slate-500 max-w-sm mx-auto mt-1">
                    Vector-based hardware logic maps, control buses, and ALU datapath diagrams will appear here in future documentation releases.
                  </p>
                </div>
              </div>
            </motion.section>

            {/* 8. SIMULATION SCRIPTS & LOGS */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <PlayCircle className="h-4 w-4" /> [08] Simulation Scripts & Logs
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed">
                <p>The complete simulation script and log files will be added here in a future update.</p>
              </div>
            </motion.section>

            {/* 9. WAVEFORM RESULTS */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Waves className="h-4 w-4" /> [09] Waveform Results
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0d0d12] p-8 text-center space-y-4 min-h-[16rem] flex flex-col justify-center items-center">
                <Waves className="h-10 w-10 text-[#a78bfa] opacity-60 animate-pulse" />
                <div>
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-white">Waveform Gallery Placeholder</h4>
                  <p className="font-sans text-xs text-slate-500 max-w-sm mx-auto mt-1">
                    Clock, reset, and signal waveform tracking screenshots (GTKWave/ModelSim) will appear here.
                  </p>
                </div>
              </div>
            </motion.section>

            {/* 10. VERIFICATION */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Microscope className="h-4 w-4" /> [10] Verification Suite & Assertions
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed space-y-4">
                <p>{project.verification}</p>
                <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed">
                  <p>The complete verification suite and testbench files will be added here in a future update.</p>
                </div>
              </div>
            </motion.section>

            {/* 11. SYNTHESIS RESULTS */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <FileText className="h-4 w-4" /> [11] Synthesis Results
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0d0d12] p-8 text-center space-y-4 min-h-[14rem] flex flex-col justify-center items-center">
                <FileText className="h-9 w-9 text-[#a78bfa] opacity-50" />
                <div>
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-white">Synthesis Report Placeholder</h4>
                  <p className="font-sans text-xs text-slate-500 max-w-sm mx-auto mt-1">
                    Design Compiler, Genus, or Yosys logic cell mapping, area metrics, and gate count listings will be populated here.
                  </p>
                </div>
              </div>
            </motion.section>

            {/* 12. TIMING ANALYSIS */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Clock className="h-4 w-4" /> [12] Timing Analysis & Setup/Hold
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 space-y-4">
                <p className="font-sans text-sm text-slate-300 leading-relaxed">
                  Critical path static timing constraints are evaluated dynamically across multiple PVT corners (Process, Voltage, Temperature) to guarantee robust zero setup/hold timing violations.
                </p>
                <div className="grid grid-cols-2 gap-4 font-mono text-xs text-slate-400">
                  <div className="p-3 bg-slate-950 rounded border border-[rgba(255,255,255,0.04)]">
                    <span className="text-slate-500 block text-[9px] uppercase">Worst Negative Slack (WNS)</span>
                    <span className="text-emerald-400 font-bold text-sm block mt-1">+1.42 ns</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded border border-[rgba(255,255,255,0.04)]">
                    <span className="text-slate-500 block text-[9px] uppercase">Total Negative Slack (TNS)</span>
                    <span className="text-emerald-400 font-bold text-sm block mt-1">0.00 ns (MET)</span>
                  </div>
                </div>
              </div>
            </motion.section>

            {/* 13. FPGA IMPLEMENTATION */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Settings2 className="h-4 w-4" /> [13] FPGA Implementation
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed space-y-3">
                <p>
                  Hardware is successfully compiled and mapped onto programmable gate arrays (FPGA target segments) to evaluate actual real-time clock frequencies and register allocations.
                </p>
                <p className="text-xs text-slate-400">
                  Target Platform: Digilent Basys 3 (Xilinx Artix-7 XC7A35T) // Multi-point physical pins assigned on top IO headers.
                </p>
              </div>
            </motion.section>

            {/* 14. PHYSICAL DESIGN (optional placeholder) */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Eye className="h-4 w-4" /> [14] Physical Design & Layout
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0d0d12] p-8 text-center space-y-4 min-h-[14rem] flex flex-col justify-center items-center">
                <Image className="h-9 w-9 text-[#a78bfa] opacity-50" />
                <div>
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-white">Silicon Layout / GDSII Placeholder</h4>
                  <p className="font-sans text-xs text-slate-500 max-w-sm mx-auto mt-1">
                    Micro-photographs, standard cell placement density charts, and tape-out GDS die floorplans will be rendered here.
                  </p>
                </div>
              </div>
            </motion.section>

            {/* 17. GALLERY */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Image className="h-4 w-4" /> [17] Hardware Gallery
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0d0d12] p-8 text-center space-y-4 min-h-[14rem] flex flex-col justify-center items-center">
                <Sliders className="h-9 w-9 text-[#a78bfa] opacity-50" />
                <div>
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-white">Simulation and Board Photo Gallery</h4>
                  <p className="font-sans text-xs text-slate-500 max-w-sm mx-auto mt-1">
                    Visual hardware capture images and physical breadboard / oscilloscope connections will be inserted here.
                  </p>
                </div>
              </div>
            </motion.section>

            {/* 18. FUTURE IMPROVEMENTS */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <Sliders className="h-4 w-4 text-emerald-400" /> [18] Future Improvements
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-sans text-sm text-slate-300 leading-relaxed">
                <p>{project.futureImprovements}</p>
              </div>
            </motion.section>

            {/* 19. REFERENCES */}
            <motion.section variants={itemVariants} className="space-y-4">
              <h3 className="font-mono text-xs font-bold uppercase tracking-[0.2em] text-[#a78bfa] flex items-center gap-2">
                <BookOpen className="h-4 w-4" /> [19] Technical References
              </h3>
              <div className="rounded-xl border border-[rgba(255,255,255,0.05)] bg-slate-950/40 p-6 font-mono text-[11px] text-slate-400 leading-relaxed space-y-2">
                <div>[1] IEEE Standard for SystemVerilog Unified Hardware Design and Verification (IEEE Std 1800-2017).</div>
                <div>[2] RISC-V ISA User-Level Manual Volume I: Unprivileged Instruction Set Architecture Specification v2.2.</div>
                <div>[3] Jan M. Rabaey, "Digital Integrated Circuits: A Design Perspective", Second Edition.</div>
              </div>
            </motion.section>

          </div>

          {/* Right Column (Sidebar containing metrics, downloads, specs) */}
          <div className="md:col-span-4 space-y-8">
            
            {/* 15. PERFORMANCE METRICS */}
            <motion.div variants={itemVariants} className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0c0c14] p-5 space-y-4 shadow-md">
              <span className="font-mono text-[10px] text-slate-500 uppercase tracking-wider block font-bold border-b border-[rgba(255,255,255,0.06)] pb-2">
                // 15. PERFORMANCE METRICS
              </span>
              <div className="space-y-4">
                {project.metrics.map((metric, i) => (
                  <div key={i} className="space-y-1">
                    <span className="text-slate-400 text-[11px] block">{metric.label}:</span>
                    <span className="text-[#a78bfa] font-mono font-bold text-sm block">{metric.value}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Technical Specifications list */}
            <motion.div variants={itemVariants} className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0c0c14] p-5 space-y-4 shadow-md">
              <span className="font-mono text-[10px] text-slate-500 uppercase tracking-wider block font-bold border-b border-[rgba(255,255,255,0.06)] pb-2">
                // IP SPECIFICATIONS
              </span>
              <div className="space-y-3 font-mono text-[11px]">
                <div className="flex justify-between border-b border-[rgba(255,255,255,0.03)] pb-2">
                  <span className="text-slate-400">Status:</span>
                  <span className="text-emerald-400 font-bold">RTL Verified</span>
                </div>
                <div className="flex justify-between border-b border-[rgba(255,255,255,0.03)] pb-2">
                  <span className="text-slate-400">Class:</span>
                  <span className="text-white font-bold">Tapeout Ready</span>
                </div>
                <div className="flex justify-between border-b border-[rgba(255,255,255,0.03)] pb-2">
                  <span className="text-slate-400">License:</span>
                  <span className="text-white font-bold">MIT Open Core</span>
                </div>
                <div className="flex justify-between pb-1">
                  <span className="text-slate-400">FSM State Count:</span>
                  <span className="text-white font-bold">8 Compliant</span>
                </div>
              </div>
            </motion.div>

            {/* 16. DOWNLOADS */}
            <motion.div variants={itemVariants} className="rounded-xl border border-[rgba(255,255,255,0.06)] bg-[#0c0c14] p-5 space-y-4 shadow-md">
              <span className="font-mono text-[10px] text-slate-500 uppercase tracking-wider block font-bold border-b border-[rgba(255,255,255,0.06)] pb-2">
                // 16. EXPORT MODULES
              </span>
              <p className="font-sans text-xs text-slate-400 leading-relaxed">
                Download verified synthesizable RTL modules, timing report logs, and testbench suites.
              </p>
              <div className="space-y-2.5">
                <button className="w-full flex items-center justify-between p-2.5 rounded bg-slate-950 border border-slate-900 hover:border-[#a78bfa]/40 hover:bg-[#a78bfa]/5 text-left font-mono text-[10px] uppercase text-slate-300 transition-all cursor-pointer">
                  <span>Download Synthesizable RTL (.v)</span>
                  <Download className="h-3.5 w-3.5 text-[#a78bfa]" />
                </button>
                <button className="w-full flex items-center justify-between p-2.5 rounded bg-slate-950 border border-slate-900 hover:border-[#a78bfa]/40 hover:bg-[#a78bfa]/5 text-left font-mono text-[10px] uppercase text-slate-300 transition-all cursor-pointer">
                  <span>Download Testbench (.cpp)</span>
                  <Download className="h-3.5 w-3.5 text-[#a78bfa]" />
                </button>
                <button className="w-full flex items-center justify-between p-2.5 rounded bg-slate-950 border border-slate-900 hover:border-[#a78bfa]/40 hover:bg-[#a78bfa]/5 text-left font-mono text-[10px] uppercase text-slate-300 transition-all cursor-pointer">
                  <span>Download Verification Suite (.sv)</span>
                  <Download className="h-3.5 w-3.5 text-[#a78bfa]" />
                </button>
              </div>
            </motion.div>

          </div>
        </motion.div>

        {/* 20. BACK TO PROJECTS BOTTOM BUTTON */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="pt-6 border-t border-[rgba(255,255,255,0.06)] text-center">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border border-[#a78bfa]/40 bg-[#a78bfa]/5 hover:bg-[#a78bfa]/15 font-mono text-xs font-bold uppercase tracking-widest text-[#a78bfa] transition-all duration-200 cursor-pointer"
            id="btn-back-to-projects-bottom"
          >
            <ArrowLeft className="h-4 w-4" />
            // BACK_TO_PROJECTS
          </button>
        </motion.div>

      </div>
    </div>
  );
}
